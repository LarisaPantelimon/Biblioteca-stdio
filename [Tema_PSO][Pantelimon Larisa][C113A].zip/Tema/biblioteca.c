#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

struct _so_file {
int descriptor;
char buffer[4096];
char *moddeschidere;
int operatie;
int error;
int index;
int ocupat;
char buffer2[4096];
int index2;
int totalwrite;
int verifica;
int proces;
int pp;
};

typedef struct _so_file SO_FILE;

#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define MAX_SIZE 4096
#define SO_EOF (-1)
int pipe_fd[2];

int so_fseek(SO_FILE *stream, long offset, int whence)
{
int reusit;
if (stream->operatie == 1 && stream->index2 != 0)
	so_fflush(stream);

reusit = lseek(stream->descriptor, offset, whence);

if (reusit == -1)
	return -1;

stream->totalwrite = reusit;
return 0;

}

SO_FILE *so_fopen(const char *pathname, const char *mode)
{
int flags;

if (strcmp(mode, "r") == 0)
	flags = O_RDONLY;
else if (strcmp(mode, "r+") == 0)
	flags = O_RDWR;
else if (strcmp(mode, "w") == 0)
	flags = O_WRONLY | O_CREAT | O_TRUNC;
else if (strcmp(mode, "w+") == 0)
	flags = O_RDWR | O_CREAT | O_TRUNC;
else if (strcmp(mode, "a") == 0)
	flags = O_WRONLY | O_APPEND | O_CREAT;
else if (strcmp(mode, "a+") == 0)
	flags = O_RDWR | O_APPEND | O_CREAT;
else
	return NULL;

int deschide = open(pathname, flags, 0666);

if (deschide == -1)
	return NULL;

SO_FILE *file = (SO_FILE *)malloc(sizeof(SO_FILE));

if (file == NULL)
	return NULL;

file->index2 = 0;

for (int i = 0; i < 4096; i++)
	file->buffer[i] = '\0';

file->descriptor = deschide;
file->operatie = -1;
file->index = 0;
file->error = 0;
file->ocupat = -1;
file->moddeschidere = strdup(mode);
file->totalwrite = 0;
file->verifica = 0;
file->pp = 0;

return file;
}

int so_fclose(SO_FILE *stream)
{
if (stream->index2 > 0) {
	int x = write(stream->descriptor, stream->buffer2, stream->index2);

if (x < 0) {
	free(stream->moddeschidere);
	free(stream);
	return SO_EOF;
}
}

int inchide = close(stream->descriptor);

free(stream->moddeschidere);
free(stream);

if (inchide == 0)
	return 0;

return SO_EOF;
}

int so_fputc(int c, SO_FILE *stream)
{
stream->operatie = 1;

if (stream->index2 == 4096) {
	stream->index2 = 0;
	int x = write(stream->descriptor, stream->buffer2, 4096);

if (x < 0) {
	stream->error = 1;
	return SO_EOF;
}

bzero(stream->buffer2, 4096);
}

if (stream->index2 <= 4096) {
	stream->buffer2[stream->index2] = (char)c;
	stream->index2++;
}

stream->totalwrite++;

return c;
}

int so_feof(SO_FILE *stream)
{
if (stream->buffer[stream->index - 1] == '\0')
	return stream->index;

return 0;
}

int so_ferror(SO_FILE *stream)
{
return stream->error;
}

int so_fflush(SO_FILE *stream)
{
int x = write(stream->descriptor, stream->buffer2, stream->index2);

if (x < 0)
	return SO_EOF;

stream->index2 = 0;
stream->totalwrite = stream->totalwrite + stream->index2;
bzero(stream->buffer2, 4096);

return 0;
}

int so_fgetc(SO_FILE *stream)
{
if (stream->operatie == 1)
	lseek(stream->descriptor, 0, SEEK_SET);

if (stream->verifica != stream->totalwrite)
	stream->index = 4096;

if (stream->ocupat < 0 || stream->index >= stream->ocupat
|| stream->operatie == 1) {
	bzero(stream->buffer, 4096);
	stream->operatie = 0;
	stream->index = 0;
	int x = read(stream->descriptor, stream->buffer, 4096);

if (x < 0) {
	stream->error = 1;
	return SO_EOF;
}

stream->ocupat = 4096;
}
int pos;
pos = stream->index;
stream->index++;
stream->totalwrite++;
stream->verifica = stream->totalwrite;

if (stream->buffer[pos] == '\0')
	return SO_EOF;

return (int)stream->buffer[pos];
}

int so_fileno(SO_FILE *stream)
{
return stream->descriptor;
}

size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
int k;
k = 0;

for (int i = 0; i < nmemb; i++) {
	for (int j = 0; j < size; j++) {
		int c = so_fgetc(stream);

if (stream->error == 1)
	return 0;

if (c == SO_EOF)
	break;

*(char *)(ptr + k) = (char)c;
k++;
}
}

return nmemb;
}

long so_ftell(SO_FILE *stream)
{
if (stream->totalwrite > -1)
	return stream->totalwrite;

return SO_EOF;
}

int so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
stream->operatie = 1;
int i = 0, j = 0;
for (i = 0; i < nmemb; i++) {
	for (j = 0; j < size; j++) {
		int c = so_fputc(*(int *)(ptr + i * size + j), stream);

if (c == SO_EOF) {
	stream->error = 1;
	return 0;
}
}
}

return nmemb;
}

SO_FILE *so_popen(const char *command, const char *type)
{
int proces_nou, status;

if (pipe(pipe_fd) < 0)
	return NULL;

proces_nou = fork();

if (proces_nou < 0)
	return NULL;

if (proces_nou == 0) {
	if (type[0] == 'r') {
		close(pipe_fd[0]);
		int verifica = dup2(pipe_fd[1], STDOUT_FILENO);

if (verifica < 0)
	return NULL;

close(pipe_fd[1]);
} else if (type[0] == 'w') {
	close(pipe_fd[1]);
	int verifica = dup2(pipe_fd[0], STDIN_FILENO);

if (verifica < 0)
	return NULL;

close(pipe_fd[0]);
}

int val = execl("/bin/sh", "sh", "-c", command, (char *)NULL);

if (val == -1)
	return NULL;

} else {
	if (type[0] == 'r') {
		close(pipe_fd[1]);
		SO_FILE *file = (SO_FILE *)malloc(sizeof(SO_FILE));

		bzero(file->buffer, 4096);
		bzero(file->buffer2, 4096);
		file->descriptor = pipe_fd[0];
		file->operatie = -1;
		file->error = 0;
		file->index = 0;
		file->index2 = 0;
		file->proces = proces_nou;
		file->ocupat = -1;
		file->verifica = 0;
		file->moddeschidere = strdup(type);
		file->pp = 1;
		file->totalwrite = 0;

		return file;
} else if (type[0] == 'w') {
	close(pipe_fd[0]);
	SO_FILE *file = (SO_FILE *)malloc(sizeof(SO_FILE));

	file->ocupat = -1;
	file->descriptor = pipe_fd[1];
	file->operatie = -1;
	file->error = 0;
	file->moddeschidere = strdup(type);
	file->index2 = 0;
	file->index = 0;
	file->verifica = 0;
	file->totalwrite = 0;
	file->pp = 1;
	file->proces = proces_nou;

	bzero(file->buffer2, 4096);

	return file;
} else {
	return NULL;
}
}
}

int so_pclose(SO_FILE *stream)
{
int status;
status = 0;
int child_pid;
child_pid = 0;

if (stream->index2 > 0)
	write(stream->descriptor, stream->buffer2, stream->index2);

int x = close(stream->descriptor);
if (x < 0)
	return SO_EOF;

child_pid = waitpid(stream->proces, &status, 0);
free(stream->moddeschidere);
free(stream);

if (child_pid >= 0)
	return 0;
else
	return (-1);
}
